package com.online.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartshopApplication.class, args);
	}

}

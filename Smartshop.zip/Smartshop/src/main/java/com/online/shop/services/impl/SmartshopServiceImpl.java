package com.online.shop.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.shop.dao.SmartshopJpaDao;
import com.online.shop.model.Smartshop;
import com.online.shop.services.SmartshopService;


@Service
@Transactional
public class SmartshopServiceImpl implements SmartshopService {
	
	private static Logger LOGGER = LoggerFactory.getLogger(SmartshopServiceImpl.class);

	@Autowired
	private SmartshopJpaDao smartshopJpaDao;
	
	@Override
	public Iterable<Smartshop> getAllProducts() {
		return smartshopJpaDao.findAll();
	}

	@Override
	public Smartshop createproduct(Smartshop smartshop) {
	        return smartshopJpaDao.save(smartshop); 
	}

	@Override
	public Smartshop updateProductById(Integer productid, String category) {
		Smartshop smartshop = smartshopJpaDao.findById(productid).get();
		smartshop.setCategory(category);
	        return smartshopJpaDao.save(smartshop);
	}

	@Override
	public Smartshop findProductByName(String name) {
		return (Smartshop)smartshopJpaDao.findProductByName(name).get();
		
	}

	
	  @Override public Optional<Smartshop> findProductCategory(String category) {
	 return smartshopJpaDao.findProductCategory(category); }
	 

	@Override
	public String deleteProductByRating() {
		  smartshopJpaDao.deleteProductByRating();
		return "deleted";
	}

	
	@Override
	public List<Smartshop> updateProductGrossPrice() {
		List<Smartshop> prod = new ArrayList<Smartshop>();
		prod= (List<Smartshop>) getAllProducts();
		for(Smartshop ele : prod) {
			ele.setTotalPrice(ele.getUnitPrice()*ele.getQuantity());
		}
		return prod;
	}

	
}

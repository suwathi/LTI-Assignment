package com.online.shop.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.online.shop.exception.ResourceNotFoundException;
import com.online.shop.model.Smartshop;
import com.online.shop.services.SmartshopService;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/shopping")
public class SmartshopController {
	
	private static Logger LOGGER = LoggerFactory.getLogger(SmartshopController.class);
	
	@Autowired
	private SmartshopService smartshopService;
	
	 @GetMapping("/getAllProducts")
	    public List<Smartshop> getAllProducts(){
		 LOGGER.info("In getAllProducts "+smartshopService.getAllProducts());
	        return (List<Smartshop>) smartshopService.getAllProducts();
	       
	    }
	 
	 @PostMapping("/createProduct")
	    public Smartshop createProduct(@RequestBody Smartshop smartshop){
		 LOGGER.info("In createProduct "+smartshopService.createproduct(smartshop));
	        return smartshopService.createproduct(smartshop);
	    }
	 
	 @PutMapping("/updateProductbyId/{productid}/{category}")
	    public Smartshop updateProductById(@PathVariable int productid,@PathVariable String category){
		 LOGGER.info("In updateProductById "+productid +"category" +category);
	        return smartshopService.updateProductById(productid, category);
	    }
	 
	
	 @PutMapping("/updateProductGrossPrice")
	    public List<Smartshop> updateProductGrossPrice(){
	        return smartshopService.updateProductGrossPrice();
	    }
	 
	 @GetMapping("/getProductByName/{name}")
	    public ResponseEntity<Smartshop> getProductByName(@PathVariable String name) throws ResourceNotFoundException{
		 Smartshop smartshop = smartshopService.findProductByName(name);
	        return ResponseEntity.ok().body(smartshop);
	    }
	 
	 @GetMapping("/getProductByCategory/{category}")
	    public Optional<Smartshop> getProductByCategory(@PathVariable String category) throws ResourceNotFoundException{
	        return smartshopService.findProductCategory(category);
	    }

	 @DeleteMapping("/deleteProductByRating")
	    public String deleteTicketById(){
		 LOGGER.info("In @DeleteMapping ");
	        return smartshopService.deleteProductByRating();
	    }
	 
	
	 
}

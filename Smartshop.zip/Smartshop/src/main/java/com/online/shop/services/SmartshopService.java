package com.online.shop.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.online.shop.model.Smartshop;


public interface SmartshopService {
	
	 Iterable<Smartshop> getAllProducts();
	 Smartshop  createproduct(Smartshop smartshop);
	 Smartshop updateProductById(Integer productid, String category);
	 List<Smartshop> updateProductGrossPrice(); 
	 Smartshop findProductByName(String name);
	 Optional<Smartshop> findProductCategory(String name);
	 String deleteProductByRating();
	 
	
}

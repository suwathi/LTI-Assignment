package com.online.shop.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.online.shop.model.Smartshop;

@Repository
public interface SmartshopJpaDao extends JpaRepository<Smartshop, Integer>{

/*
	@Query("select t from smartshop t where t.name=:name")
	Optional<Smartshop> findProductByName(String name);

	
	  @Query("select t from smartshop t where t.category=:category")
	  Optional<Smartshop> findProductCategory(String category);

	  @Query("delete from smartshop t where t.rating<2")
	  int deleteProductByRating();
	  */

}

package com.bank.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProducerApplicationTests {

	//@Test
	void contextLoads() {
	}

}

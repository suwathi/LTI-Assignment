package com.bank.consumer;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerClientConsumerApplicationTests {

	//@Test
	//void contextLoads() {
	//}

}

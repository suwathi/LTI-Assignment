package com.bank.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerClientConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerClientConsumerApplication.class, args);
	}

}

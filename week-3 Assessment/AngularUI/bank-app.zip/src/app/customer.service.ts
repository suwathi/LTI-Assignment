import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  //constructor(private http:HttpClient) { }
  constructor(private http: HttpClient) { }

  private baseUrl = 'http://localhost:8769/bank/customers';

  createCustomer(customer:Object) : Observable<Object>{
    console.log('createCustomer'+customer);
    return this.http.post(`${this.baseUrl}`,customer);
  }

  getCustomer(id:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  //updateCustomer(id:number,value:any):Observable<Object>{
  updateCustomer(id:number,customer:Object):Observable<Object>{
    console.log("update customer "+customer)
    return this.http.put(`${this.baseUrl}/${id}`,customer);
  }

  deleteCustomer(id:number): Observable<any>{
    return this.http.delete(`${this.baseUrl}/${id}`,{responseType:'text'});
  }

  getCustomerList():Observable<any>{
    return this.http.get(`${this.baseUrl}`);
  }
}

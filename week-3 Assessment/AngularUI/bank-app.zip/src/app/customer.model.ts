export class Customer {
    id?: any;
    name?: string;
    age?: string;
    address?: string;
    typeOfAccount?: string;
}

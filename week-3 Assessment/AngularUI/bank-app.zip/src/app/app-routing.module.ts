import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { ConsumerListComponent } from './consumer-list/consumer-list.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { UpdateCustomerComponent } from './update-customer/update-customer.component';

const routes: Routes = [
  {path:'',redirectTo:'customer',pathMatch:'full'},
  {path:'customers', component:CustomerListComponent },
  {path:'add',component:AddCustomerComponent},
  {path:'update/:id',component:UpdateCustomerComponent},
  {path:'details/:id',component:CustomerDetailsComponent},
  {path:'consumer',component:ConsumerListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

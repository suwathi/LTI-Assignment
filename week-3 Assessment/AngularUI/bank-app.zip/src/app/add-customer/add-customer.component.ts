import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer.model';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  customer:Customer = new Customer();
  submitted=false;
  requiredForm!: FormGroup;
  

  constructor(private customerService:CustomerService,
    private router:Router,private fb : FormBuilder) {
      this.myForm();
     }

     myForm(){
       this.requiredForm=this.fb.group({
         name:['',Validators.required]
       });
     }

    ngOnInit() {
    }

    newCustomer(): void{
      this.submitted=false;
      this.customer= new Customer();
    }

    onSubmit(){
      this.submitted = true;
      this.save();
    }

    save(){
      this.customerService.createCustomer(this.customer).subscribe(
        data => {
          console.log(data)
          this.customer=new Customer();
          this.gotoList();
        },
        error => console.log(error)); 

    }
 
    gotoList(){
      this.router.navigate(['/customers']);
    }



}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Customer } from '../customer.model';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-consumer-list',
  templateUrl: './consumer-list.component.html',
  styleUrls: ['./consumer-list.component.css']
})
export class ConsumerListComponent implements OnInit {

  customers?:  Observable<Customer[]>;

  constructor(private customerService:CustomerService,
    private router:Router) { }

  ngOnInit(){
    this.reloadData();
  }

  reloadData(){
    console.log("reload")
    this.customers=this.customerService.getCustomerList();
  }
}
